from setuptools import setup
from setuptools.dist import Distribution


class BinaryDistribution(Distribution):
    """Force setuptools a taguer le wheel comme specifique a une plateforme,
    parce que le paquet contient libg.so (compile), pas du pur Python."""
    def has_ext_modules(self):
        return True


setup(distclass=BinaryDistribution)
