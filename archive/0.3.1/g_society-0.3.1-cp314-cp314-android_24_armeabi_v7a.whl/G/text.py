"""
G.text
----------------------------------------------------------------
Tokenizer BPE (Byte Pair Encoding) au niveau des octets -- la meme
technique que GPT-2/GPT-3. Brique de base pour le futur module
chatbot (V2) : avant de pouvoir entrainer un reseau sur du texte, il
faut pouvoir transformer ce texte en nombres (et inversement).

Pourquoi "au niveau des octets" plutot que caractere par caractere :
le vocabulaire de depart est fixe (256 = toutes les valeurs d'octet
possibles), donc N'IMPORTE QUEL texte Unicode (accents francais,
emojis, toute langue) peut toujours etre encode puis reconstruit a
l'identique -- meme un caractere jamais vu a l'entrainement, puisqu'il
se decompose simplement en octets deja connus.

Principe du BPE : on part des octets individuels, et on fusionne
repetitivement la paire d'octets/tokens la plus frequente du corpus en
un nouveau token, jusqu'a atteindre la taille de vocabulaire voulue.
Plus le vocabulaire est grand, moins un texte prend de tokens (mais
plus l'entrainement du tokenizer est long).
"""

import re
import json
from collections import defaultdict

# Pre-tokenisation : decoupe le texte en "chunks" (mot + espace precedent,
# ou ponctuation, ou espaces) AVANT le BPE -- empeche de fusionner a travers
# les frontieres de mots (standard dans tous les tokenizers BPE modernes).
_PRETOKEN_PATTERN = re.compile(r""" ?\w+| ?[^\s\w]+|\s+""")


class Tokenizer:
    """Tokenizer BPE au niveau des octets.

    Exemple :
        tok = Tokenizer()
        tok.train(["le robot marche vers la cible", "le robot tombe"], vocab_size=300)
        ids = tok.encode("le robot marche")
        text = tok.decode(ids)
        assert text == "le robot marche"
    """

    def __init__(self):
        self.merges = []            # liste ordonnee de paires (id1, id2) fusionnees
        self.merge_rank = {}        # (id1, id2) -> rang (ordre d'apprentissage)
        self.pair_to_new_id = {}    # (id1, id2) -> id du token fusionne
        self.vocab = {i: bytes([i]) for i in range(256)}  # id -> octets qu'il represente
        self.special_tokens = {}       # str -> id
        self.special_tokens_inv = {}   # id -> str

    @property
    def vocab_size(self):
        return len(self.vocab) + len(self.special_tokens)

    def add_special_tokens(self, tokens):
        """Ajoute des tokens speciaux (ex: '<pad>', '<bos>', '<eos>', '<unk>').
        Ils ont leur propre id, en dehors de l'espace des 256 octets + fusions.
        Usage : prepends/append leur id manuellement autour de tes sequences,
        ex: [tok.special_tokens['<bos>']] + tok.encode(texte) + [tok.special_tokens['<eos>']]
        (ce tokenizer ne les detecte pas automatiquement DANS un texte brut)."""
        next_id = 256 + len(self.merges) + len(self.special_tokens)
        for t in tokens:
            if t not in self.special_tokens:
                self.special_tokens[t] = next_id
                self.special_tokens_inv[next_id] = t
                next_id += 1

    def _pretokenize(self, text):
        return _PRETOKEN_PATTERN.findall(text)

    def train(self, texts, vocab_size=1000, verbose=False):
        """Apprend les fusions BPE a partir d'un texte ou d'une liste de textes.
        vocab_size doit etre >= 256 (le vocabulaire de base)."""
        if isinstance(texts, str):
            texts = [texts]
        if vocab_size < 256:
            raise ValueError("vocab_size doit etre >= 256 (256 octets de base)")

        word_freq = defaultdict(int)
        for text in texts:
            for chunk in self._pretokenize(text):
                word_freq[chunk] += 1

        # chaque "mot" pretokenize devient un tuple d'ids (au depart, ses octets bruts)
        words = {tuple(chunk.encode("utf-8")): freq for chunk, freq in word_freq.items()}

        num_merges = vocab_size - 256
        for i in range(num_merges):
            pair_counts = defaultdict(int)
            for word, freq in words.items():
                for a, b in zip(word, word[1:]):
                    pair_counts[(a, b)] += freq
            if not pair_counts:
                break  # plus aucune paire a fusionner (corpus trop petit/simple)

            best_pair = max(pair_counts, key=pair_counts.get)
            new_id = 256 + i
            self.vocab[new_id] = self.vocab[best_pair[0]] + self.vocab[best_pair[1]]
            self.merges.append(best_pair)
            self.merge_rank[best_pair] = i
            self.pair_to_new_id[best_pair] = new_id

            words = {self._apply_merge(word, best_pair, new_id): freq
                     for word, freq in words.items()}

            if verbose and (i % 100 == 0 or i == num_merges - 1):
                print(f"fusion {i + 1}/{num_merges} : {best_pair} -> {new_id}  "
                      f"(vocab actuel = {256 + i + 1})")

    @staticmethod
    def _apply_merge(word, pair, new_id):
        """Remplace TOUTES les occurrences consecutives de `pair` par `new_id` dans `word`."""
        result = []
        i = 0
        n = len(word)
        while i < n:
            if i < n - 1 and (word[i], word[i + 1]) == pair:
                result.append(new_id)
                i += 2
            else:
                result.append(word[i])
                i += 1
        return tuple(result)

    def _encode_chunk(self, chunk):
        ids = list(chunk.encode("utf-8"))
        if len(ids) < 2:
            return ids
        while len(ids) >= 2:
            pairs = set(zip(ids, ids[1:]))
            # on applique toujours la fusion apprise EN PREMIER parmi celles presentes
            # (c'est la plus "fondamentale" -- standard pour l'encodage BPE)
            candidate = min(pairs, key=lambda p: self.merge_rank.get(p, float("inf")))
            if candidate not in self.merge_rank:
                break
            new_id = self.pair_to_new_id[candidate]
            ids = list(self._apply_merge(tuple(ids), candidate, new_id))
        return ids

    def encode(self, text):
        """Texte -> liste d'ids. Ne detecte pas les tokens speciaux dans le texte brut
        (voir add_special_tokens)."""
        ids = []
        for chunk in self._pretokenize(text):
            ids.extend(self._encode_chunk(chunk))
        return ids

    def decode(self, ids):
        """Liste d'ids -> texte. Round-trip exact avec encode() (meme accents/emojis),
        sauf si la liste contient des ids de tokens speciaux (rendus entre chevrons)."""
        parts = []
        buffer = bytearray()
        for i in ids:
            if i in self.special_tokens_inv:
                if buffer:
                    parts.append(bytes(buffer))
                    buffer = bytearray()
                parts.append(self.special_tokens_inv[i].encode("utf-8"))
            else:
                buffer.extend(self.vocab[i])
        if buffer:
            parts.append(bytes(buffer))
        return b"".join(parts).decode("utf-8", errors="replace")

    def save(self, path):
        """Sauvegarde les fusions apprises (le vocabulaire se reconstruit a partir
        d'elles au chargement -- pas besoin de le stocker separement)."""
        data = {
            "merges": self.merges,
            "special_tokens": self.special_tokens,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)

    def load(self, path):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        self.merges = [tuple(p) for p in data["merges"]]
        self.merge_rank = {}
        self.pair_to_new_id = {}
        self.vocab = {i: bytes([i]) for i in range(256)}
        for rank, pair in enumerate(self.merges):
            new_id = 256 + rank
            self.vocab[new_id] = self.vocab[pair[0]] + self.vocab[pair[1]]
            self.merge_rank[pair] = rank
            self.pair_to_new_id[pair] = new_id
        self.special_tokens = dict(data.get("special_tokens", {}))
        self.special_tokens_inv = {v: k for k, v in self.special_tokens.items()}
