"""
G.seq
----------------------------------------------------------------
Briques pour traiter des SEQUENCES (texte tokenise par G.text) :
une couche d'embedding, une cellule recurrente (RNN simple, type
Elman), et un petit modele de langage de bout en bout.

Tout est construit avec les primitives DEJA existantes de G (Tensor,
Dense, matmul, tanh) -- aucun changement du moteur C n'etait
necessaire pour ca.

Comment l'embedding marche sans operation de "lookup" dediee dans le
moteur : un token d'id i est transforme en vecteur one-hot (que des 0,
sauf un 1 a la position i), puis multiplie par la matrice d'embedding
(vocab_size x embed_dim). Multiplier un one-hot par une matrice revient
exactement a EXTRAIRE la ligne i de cette matrice -- une astuce
standard qui reutilise le matmul deja teste du moteur plutot que
d'ajouter une nouvelle operation en C.
"""

from .tensor import Tensor
from . import nn


# ============================================================
# Embedding
# ============================================================

class Embedding:
    """Table d'embedding : transforme des ids de tokens en vecteurs continus
    appris. Les vecteurs sont appris comme n'importe quel poids (le gradient
    remonte depuis la suite du reseau jusqu'a cette table).

    Exemple :
        emb = Embedding(vocab_size=300, embed_dim=16)
        vectors = emb(token_ids)   # Tensor (len(token_ids) x embed_dim)
    """

    def __init__(self, vocab_size, embed_dim, seed=42):
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.weight = Tensor.randn(vocab_size, embed_dim, requires_grad=True, seed=seed)
        self.weight.protect()  # survit a free_graph() -- comme les poids d'un Dense

    def _one_hot_batch(self, token_ids):
        rows = []
        for tid in token_ids:
            row = [0.0] * self.vocab_size
            row[tid] = 1.0
            rows.append(row)
        return Tensor(rows)

    def __call__(self, token_ids):
        """token_ids : liste d'entiers. Renvoie un Tensor (len(token_ids) x embed_dim)."""
        one_hot = self._one_hot_batch(token_ids)
        return one_hot.matmul(self.weight)

    def parameters(self):
        return [self.weight]


# ============================================================
# Cellule recurrente (RNN simple, type Elman)
# ============================================================

class RNNCell:
    """Une cellule recurrente classique :
        h_t = tanh(x_t . Wxh + h_{t-1} . Whh + b)

    Garde une "memoire" (l'etat cache h) qui se transmet d'un pas de
    temps au suivant -- ce qui manque a une simple Dense pour traiter
    des sequences (une Dense traite chaque entree independamment, sans
    se souvenir de ce qui precede).
    """

    def __init__(self, input_size, hidden_size, seed=42):
        self.hidden_size = hidden_size
        self.Wxh = nn.Dense(input_size, hidden_size, activation="none", seed=seed)
        self.Wxh.bias.set_data([0.0] * hidden_size)  # evite un double biais avec Whh
        self.Whh = nn.Dense(hidden_size, hidden_size, activation="none", seed=seed + 1)

    def init_hidden(self):
        return Tensor(rows=1, cols=self.hidden_size, requires_grad=False)

    def step(self, x_t, h_prev):
        """Un seul pas de temps. x_t : Tensor (1 x input_size). h_prev : Tensor (1 x hidden_size).
        Renvoie le nouvel etat cache h_t (1 x hidden_size)."""
        pre = self.Wxh(x_t) + self.Whh(h_prev)
        return pre.tanh()

    def forward_sequence(self, x_seq_rows):
        """x_seq_rows : liste de listes de floats, UNE PAR PAS DE TEMPS (deja les
        embeddings, sous forme de valeurs Python -- voir TinyLanguageModel pour
        pourquoi on repasse par des valeurs plutot que par le Tensor empile directement).
        Renvoie la liste des etats caches [h_1, ..., h_T] (chacun 1 x hidden_size),
        CHAQUE h_t reste connecte au graphe d'autograd en remontant jusqu'a x_seq_rows
        si ces valeurs proviennent elles-memes d'un Tensor relie a des poids appris
        (ce qui est le cas dans TinyLanguageModel : Wxh(x_t) reconstruit le lien)."""
        h = self.init_hidden()
        hiddens = []
        for row in x_seq_rows:
            x_t = Tensor([row])
            h = self.step(x_t, h)
            hiddens.append(h)
        return hiddens

    def parameters(self):
        return self.Wxh.parameters() + self.Whh.parameters()


# ============================================================
# GRU (Gated Recurrent Unit) -- memoire a plus long terme que RNNCell
# ============================================================

class GRUCell:
    """Cellule recurrente a PORTES (comme RNNCell, mais plus solide sur le
    long terme). Trois sous-calculs a chaque pas de temps :

      z_t (porte de mise a jour)  = sigmoid(x_t.Wxz + h_{t-1}.Whz)
      r_t (porte de reinitialisation) = sigmoid(x_t.Wxr + h_{t-1}.Whr)
      h~_t (candidat)             = tanh(x_t.Wxh + (r_t * h_{t-1}).Whh)
      h_t                         = (1 - z_t) * h_{t-1} + z_t * h~_t

    Intuition : z_t decide COMBIEN du nouveau contenu (h~_t) remplace
    l'ancien etat, et r_t decide combien de l'ancien etat compte encore
    pour calculer ce nouveau contenu. Avec RNNCell, l'etat cache est
    entierement recalcule a chaque pas -- un signal lointain s'estompe
    vite (gradient qui s'evanouit sur de longues sequences). Ici, si
    z_t reste proche de 0, h_t peut recopier h_{t-1} presque sans
    changement, ce qui permet de preserver une information sur
    beaucoup plus de pas de temps.

    Construite entierement avec des briques DEJA existantes de G
    (Dense, sigmoid, tanh, multiplication elementwise) -- aucun nouvel
    ajout au moteur C n'a ete necessaire pour cette cellule."""

    def __init__(self, input_size, hidden_size, seed=42):
        self.hidden_size = hidden_size
        self.Wxz = nn.Dense(input_size, hidden_size, activation="none", seed=seed)
        self.Whz = nn.Dense(hidden_size, hidden_size, activation="none", seed=seed + 1)
        self.Wxr = nn.Dense(input_size, hidden_size, activation="none", seed=seed + 2)
        self.Whr = nn.Dense(hidden_size, hidden_size, activation="none", seed=seed + 3)
        self.Wxh = nn.Dense(input_size, hidden_size, activation="none", seed=seed + 4)
        self.Wxh.bias.set_data([0.0] * hidden_size)  # evite un double biais avec Whh
        self.Whh = nn.Dense(hidden_size, hidden_size, activation="none", seed=seed + 5)
        self._ones = Tensor([[1.0] * hidden_size])  # constante, pas de gradient
        self._ones.protect()  # BUG EVITE : sans ca, free_graph() la liberait apres le
        # 1er pas (elle est "parent" de one_minus_z a CHAQUE pas de temps), causant un
        # use-after-free des le pas suivant -- meme categorie de bug que pour Embedding.

    def init_hidden(self):
        return Tensor(rows=1, cols=self.hidden_size, requires_grad=False)

    def step(self, x_t, h_prev):
        z = (self.Wxz(x_t) + self.Whz(h_prev)).sigmoid()
        r = (self.Wxr(x_t) + self.Whr(h_prev)).sigmoid()
        h_candidate = (self.Wxh(x_t) + self.Whh(r * h_prev)).tanh()
        one_minus_z = z.scale(-1.0) + self._ones
        return (one_minus_z * h_prev) + (z * h_candidate)

    def parameters(self):
        return (self.Wxz.parameters() + self.Whz.parameters()
                + self.Wxr.parameters() + self.Whr.parameters()
                + self.Wxh.parameters() + self.Whh.parameters())


# ============================================================
# Petit modele de langage de bout en bout (embedding + RNN + sortie)
# ============================================================

class TinyLanguageModel:
    """Embedding -> RNNCell -> Dense(vocab_size) : predit le prochain token
    a partir des tokens precedents. Entraine par RETROPROPAGATION A TRAVERS
    LE TEMPS (BPTT) : la loss totale (somme des pertes de chaque position de
    la sequence) est retropropagee EN UNE FOIS, ce qui fait remonter le
    gradient a travers tous les pas de temps jusqu'aux poids de l'embedding.

    La sortie produit des LOGITS BRUTS (pas d'activation), et l'entrainement
    utilise un vrai softmax + entropie croisee (G.nn.cross_entropy_loss,
    fusionnes et stables numeriquement -- voir c/tensor.c). Une premiere
    version utilisait sigmoid+MSE : ca marchait sur un motif jouet parfait
    (4 symboles equilibres) mais s'effondrait completement sur du vrai texte
    (le modele predisait toujours le token le plus frequent, peu importe le
    contexte) -- verifie, puis corrige avec un vrai softmax+entropie croisee.

    Exemple :
        lm = TinyLanguageModel(vocab_size=300, embed_dim=16, hidden_size=32)
        opt = nn.SGD(lm.parameters(), lr=0.1)
        for epoch in range(200):
            loss = lm.train_step(token_ids, opt)
        generated = lm.generate(prompt_ids, length=20)
    """

    def __init__(self, vocab_size, embed_dim=16, hidden_size=32, seed=42, cell_type="gru"):
        """cell_type : "gru" (par defaut -- meilleure memoire long terme) ou
        "rnn" (plus simple/leger, suffisant pour de tres courtes sequences)."""
        self.vocab_size = vocab_size
        self.embedding = Embedding(vocab_size, embed_dim, seed=seed)
        if cell_type == "gru":
            self.rnn = GRUCell(embed_dim, hidden_size, seed=seed + 1)
        elif cell_type == "rnn":
            self.rnn = RNNCell(embed_dim, hidden_size, seed=seed + 1)
        else:
            raise ValueError('cell_type doit etre "gru" ou "rnn"')
        self.output = nn.Dense(hidden_size, vocab_size, activation="none", seed=seed + 2)

    def parameters(self):
        return self.embedding.parameters() + self.rnn.parameters() + self.output.parameters()

    def _one_hot(self, token_id):
        row = [0.0] * self.vocab_size
        row[token_id] = 1.0
        return row

    def _forward_logits(self, token_ids):
        """token_ids (longueur T) -> liste de T Tensors de logits (1 x vocab_size),
        TOUS encore connectes au graphe d'autograd (embedding -> rnn -> output).
        Un embedding separe par pas de temps (plutot qu'un seul gros matmul pour
        toute la sequence) : c'est ce qui garde CHAQUE pas relie individuellement
        a self.embedding.weight, condition necessaire pour que le gradient mette
        vraiment a jour la table d'embedding via BPTT."""
        h = self.rnn.init_hidden()
        logits = []
        for tid in token_ids:
            x_t = self.embedding([tid])   # Tensor (1 x embed_dim), relie a embedding.weight
            h = self.rnn.step(x_t, h)
            logits.append(self.output(h))
        return logits

    def train_step(self, token_ids, opt):
        """Un pas d'entrainement : predire token_ids[t+1] a partir de token_ids[0..t].
        Renvoie la loss moyenne par position (float)."""
        if len(token_ids) < 2:
            return None
        inputs = token_ids[:-1]
        targets = token_ids[1:]

        logits_seq = self._forward_logits(inputs)

        opt.zero_grad()
        total_loss = None
        for logit_t, target_id in zip(logits_seq, targets):
            target_tensor = Tensor([self._one_hot(target_id)])
            step_loss = nn.cross_entropy_loss(logit_t, target_tensor)
            total_loss = step_loss if total_loss is None else total_loss + step_loss

        total_loss.backward()
        opt.step()
        loss_value = total_loss.data / len(logits_seq)
        total_loss.free_graph()  # libere tout l'ephemere ; embedding/rnn/output sont proteges
        return loss_value

    def generate(self, prompt_ids, length=20, repetition_penalty=1.3, penalty_window=8):
        """Genere `length` tokens de plus apres prompt_ids.

        repetition_penalty : affaiblit le score des tokens recemment generes
        (divise leur logit par ce facteur) avant de choisir le suivant --
        sans ca, un decodage glouton (argmax pur) tombe facilement dans une
        boucle ("tomber tomber tomber...") des qu'il derive legerement de ce
        qu'il a vu a l'entrainement. C'est un defaut CONNU du decodage glouton
        en general (pas specifique a G) ; la penalite de repetition est la
        parade standard (utilisee par ex. dans GPT-2). Mets a 1.0 pour
        desactiver et revenir a un argmax pur.

        LIMITE CONNUE (memoire) : contrairement a train_step(), cette methode ne
        nettoie PAS le graphe au fur et a mesure -- chaque etat cache depend du
        precedent, donc le liberer trop tot casse la chaine pour les pas
        suivants. Pour un usage ponctuel (une reponse de chatbot), le cout est
        negligeable ; a revoir si generate() est appelee en tres grand nombre
        dans une boucle serree."""
        tokens = list(prompt_ids)
        h = self.rnn.init_hidden()
        for tid in tokens:
            x_t = self.embedding([tid])
            h = self.rnn.step(x_t, h)

        for _ in range(length):
            logits = self.output(h)
            scores = list(logits.data if isinstance(logits.data[0], (int, float)) else logits.data[0])

            if repetition_penalty != 1.0:
                recent = set(tokens[-penalty_window:])
                for tid in recent:
                    scores[tid] = scores[tid] / repetition_penalty if scores[tid] > 0 else scores[tid] * repetition_penalty

            next_token = max(range(self.vocab_size), key=lambda i: scores[i])
            tokens.append(next_token)
            x_t = self.embedding([next_token])
            h = self.rnn.step(x_t, h)
        return tokens
